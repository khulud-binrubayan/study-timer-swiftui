import SwiftUI

struct ContentView: View {
    
    @State private var subject: String = ""
    @State private var studyMinutes: Int = 25
    @State private var timeRemaining: Int = 25 * 60  
    @State private var isRunning: Bool = false
    @State private var showMessage = false
    @State private var timeInput = "25"
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 30) {
            
            // MARK: - Title
            Text("Study Timer")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 40)
            
            
            TextField("Enter subject name", text: $subject)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .padding(.horizontal)
            
            // MARK: - Timer Display
            Text(timeString(from: timeRemaining))
                .font(.system(size: 70, weight: .light, design: .rounded))
                .foregroundColor(.blue)
                .padding()
            
            // MARK: - Increase / Decrease Buttons
            HStack(spacing: 40) {
                Button(action: decreaseTime) {
                    Image(systemName: "minus.circle.fill")
                        .font(.system(size: 44))
                        .foregroundColor(.red)
                }
                
                TextField("Minutes", value: $studyMinutes, format: .number)
                    .keyboardType(.numberPad)
                    .multilineTextAlignment(.center)
                    .frame(width : 100)
                    .font(.title2)
                    .fontWeight(.medium)
                    .onChange(of: studyMinutes){ 
                        if  studyMinutes > 0 && !isRunning {
                            timeRemaining = studyMinutes * 60
                        }
                    }
                
                Button(action: increaseTime) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 44))
                        .foregroundColor(.green)
                }
            }
            if showMessage {
                Text("Time is up!")
                    .foregroundColor(.green)
                    .padding()
            }
            // MARK: - Start / Reset Buttons
            HStack(spacing: 20) {
                Button(action: {if !subject.trimmingCharacters(in: .whitespaces).isEmpty { startTimer()
                }}) {
                    Text(isRunning ? "Pause" : "Start")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(width: 120, height: 50)
                        .background(isRunning ? Color.orange : Color.blue)
                        .cornerRadius(12)
                        .disabled(subject.trimmingCharacters(in: .whitespaces).isEmpty)
                        .opacity(subject.trimmingCharacters(in: .whitespaces).isEmpty ? 0.5 : 1)
                }
                
                Button(action: resetTimer) {
                    Text("Reset")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(width: 120, height: 50)
                        .background(Color.gray)
                        .cornerRadius(12)
                }
            }
            
            Spacer()
        }
        .padding()
        // MARK: - Timer Logic
        .onReceive(timer) { _ in
            if isRunning && timeRemaining > 0 {
                timeRemaining -= 1
            } else if timeRemaining == 0 {
                isRunning = false
                showMessage = true
            }
        }
    }
    
    
    func timeString(from seconds: Int) -> String {
        let minutes = seconds / 60
        let secs = seconds % 60
        return String(format: "%02d:%02d", minutes, secs)
    }
    
    func startTimer() {
        isRunning.toggle()
    }
    
    func resetTimer() {
        isRunning = false
        timeRemaining = studyMinutes * 60
        showMessage = false
    }
    
    func increaseTime() {
        studyMinutes += 1
        if !isRunning {
            timeRemaining = studyMinutes * 60
        }
    }
    
    func decreaseTime() {
        if studyMinutes > 1 {
            studyMinutes -= 1
            if !isRunning {
                timeRemaining = studyMinutes * 60
            }
        }
    }
}

